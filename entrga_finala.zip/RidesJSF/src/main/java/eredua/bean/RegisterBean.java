package eredua.bean;

import businessLogic.BLFacade;
import configuration.UtilDate;
import domain.User;
import exceptions.RideAlreadyExistException;
import exceptions.RideMustBeLaterThanTodayException;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

@Named("Register")
@ApplicationScoped
public class RegisterBean {

	private String name;
	private String email;
	private String password;
	private String mota;

	BLFacade facadeBL=FacadeBean.getBusinessLogic(); // Negozioaren logika sortu

	public String addDriver() {
		facadeBL=FacadeBean.getBusinessLogic();
		User u = facadeBL.createUser(email, name, password, mota);
		if (u == null) {
		    FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Email hori duen erabiltzailea existitzen da, login egin edo beste email batekin probatu", null));
		    this.name="";
		    this.email="";
		    this.password="";
		    return null;
		}

		return "Login";
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
    public String getMota() {
        return mota;
    }

    public void setMota(String mota) {
        this.mota = mota;
    }
	
	public String login() {
		return "Login";
	}
	
}
