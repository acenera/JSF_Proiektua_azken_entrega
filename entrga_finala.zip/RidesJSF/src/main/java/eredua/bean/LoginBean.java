package eredua.bean;

import businessLogic.BLFacade;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

@Named("Login")
@ApplicationScoped
public class LoginBean {

	private String email;
	private String password;

	BLFacade facadeBL=FacadeBean.getBusinessLogic(); // Negozioaren logika sortu
	
	public String logeatu() {
		if(facadeBL.LoginDriver(email, password)) {
			CreateRidesBean.setDriverEmail(email);
			this.email="";
			return "Main";
		}else if(facadeBL.LoginTraveler(email, password)){
			ReserbatuBean.setTraveler(email);
			this.email="";
			return "Reserbatu";
		}else {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Ez da aurkitu email hori duen erabiltzailea edo pasahitza gaizki idatzu duzu, erregistratu edo beste pasahitz bat erabili.", null));
			this.email="";
			this.password="";
			return null;
		}
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String register() {
		return "Register";
	}
	
}