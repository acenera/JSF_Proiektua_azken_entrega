package eredua.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import businessLogic.BLFacade;
import configuration.UtilDate;
import domain.Driver;
import domain.Ride;
import exceptions.RideAlreadyExistException;
import exceptions.RideMustBeLaterThanTodayException;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.event.AjaxBehaviorEvent;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import org.primefaces.event.SelectEvent;


@Named("Main")
@SessionScoped
public class MainBean implements Serializable{
	
	BLFacade facadeBL=FacadeBean.getBusinessLogic();
	
	public MainBean() {
		
	}
		
	public String queryRides() {
        return "QueryRides"; 
    }
	
	public String createRides() {
        return "CreateRides";
    }
	
	public String logOut() {
		CreateRidesBean.setDriverEmail("");
		ReserbatuBean.setTraveler("");
		return "Login";
	}

}
