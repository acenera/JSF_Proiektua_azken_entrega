package eredua.bean;

import java.util.List;

import businessLogic.BLFacade;
import domain.Reserba;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

@Named("Kontsultatu")
@ApplicationScoped
public class KontsultatuBean {

	private List<Reserba> reserbaGuztiak;
	
	BLFacade facadeBL = FacadeBean.getBusinessLogic();
	
	 public KontsultatuBean() {
	 }

	 public List<Reserba> getReserbaGuztiak() {
		 this.resebaGuztiakLortu();
		 return reserbaGuztiak;
	 }

	 public void setReserbaGuztiak(List<Reserba> reserbaGuztiak) {
		 this.reserbaGuztiak = reserbaGuztiak;
	 }
	 
	 public void resebaGuztiakLortu() {
		 this.reserbaGuztiak = facadeBL.reserbakLortu(ReserbatuBean.getTraveler());
	 }
	 
	 public String reserbatu() {
	    return "Reserbatu";
	 }
}
