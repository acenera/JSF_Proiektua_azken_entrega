package eredua.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import businessLogic.BLFacade;
import configuration.UtilDate;
import domain.Reserba;
import domain.Ride;
import domain.Traveler;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.event.AjaxBehaviorEvent;
import jakarta.inject.Named;

@Named("Reserbatu")
@ApplicationScoped
public class ReserbatuBean {

    private String departCity;
    private String arrivalCity;
    private Date date;
    private static String traveler;

    private List<Ride> unekoBidaiak;

    BLFacade facadeBL = FacadeBean.getBusinessLogic();

    public ReserbatuBean() {}


    @PostConstruct
    public void init() {
        List<String> departCities = getDepartCities();
        if (!departCities.isEmpty()) {
            departCity = departCities.get(0);
            updateArrivalCities();
            listenerDate();
        }
    }

    public String queryRides() { return "QueryRides"; }
    public String createRides() { return "CreateRides"; }


    public String getDepartCity() { return departCity; }
    public void setDepartCity(String departCity) { this.departCity = departCity; }

    public String getArrivalCity() { return arrivalCity; }
    public void setArrivalCity(String arrivalCity) { this.arrivalCity = arrivalCity; }

    public Date getDate() { return date; }
    public void setDate(Date date) { this.date = date; }

    public List<Ride> getUnekoBidaiak() { return unekoBidaiak; }

    public static String getTraveler() {
		return traveler;
	}

	public static void setTraveler(String travele) {
		traveler = travele;
	}

	public List<String> getDepartCities() {
        return facadeBL.getDepartCities();
    }

    public List<String> getArrivalCities() {
        if (departCity == null || departCity.isEmpty())
            return new ArrayList<>();
        return facadeBL.getDestinationCities(departCity);
    }

    private void updateArrivalCities() {
        List<String> arrivals = getArrivalCities();
        if (!arrivals.isEmpty()) {
            arrivalCity = arrivals.get(0);
        } else {
            arrivalCity = null;
        }
    }

    public void listenerDate() {
        if (departCity != null && arrivalCity != null && date != null) {
            Date day = UtilDate.trim(date);
            unekoBidaiak = facadeBL.getRides(departCity, arrivalCity, day);

            FacesMessage message;
            if (unekoBidaiak.isEmpty()) {
                message = new FacesMessage(FacesMessage.SEVERITY_INFO, "No rides found", null);
            } else {
                message = new FacesMessage(FacesMessage.SEVERITY_INFO,
                        "Rides found: " + unekoBidaiak.size(), null);
            }
            FacesContext.getCurrentInstance().addMessage(null, message);

        } else {
            if (unekoBidaiak != null) unekoBidaiak.clear();
        }
    }
    
    public void reserbatu(String driver) {
    	Reserba reserba=null;
    	for (Ride i : this.unekoBidaiak) {
    		if (i.getDriver().getEmail().equals(driver)) {
    			System.out.println(i.getDriver().getEmail());
    			reserba=new Reserba(traveler, i);
    		}
    	}
    	System.out.println(driver);
    	System.out.println(reserba);
    	FacesMessage message;
    	if(reserba==null) {
    		message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Errorea gertatu da zure reserba gordetzean.", null);
    	}else {
    		facadeBL.addReserba(reserba);
    		message = new FacesMessage(FacesMessage.SEVERITY_INFO, "Reserba ondo gorde da.", null);
    	}
    	FacesContext.getCurrentInstance().addMessage(null, message);
    }
    
    public String kontsultatu() {
    	return "Kontsultatu";
    }

    public void listenerFrom(AjaxBehaviorEvent event) {
        updateArrivalCities();  
        listenerDate();         
    }

    public void listenerTo(AjaxBehaviorEvent event) {
        listenerDate();         
    }

}
