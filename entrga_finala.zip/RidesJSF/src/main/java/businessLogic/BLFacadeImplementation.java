package businessLogic;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.jws.WebMethod;
import javax.jws.WebService;

import configuration.ConfigXML;
import dataAccess.DataAccess;
import domain.Ride;
import domain.Traveler;
import domain.User;
import domain.Driver;
import domain.Reserba;
import exceptions.RideMustBeLaterThanTodayException;
import exceptions.RideAlreadyExistException;

/**
 * It implements the business logic as a web service.
 */
@WebService(endpointInterface = "businessLogic.BLFacade")
public class BLFacadeImplementation  implements BLFacade {
	private static DataAccess dbManager = new DataAccess();


//	public BLFacadeImplementation()  {		
//		System.out.println("Creating BLFacadeImplementation instance");
//		
//		
//		    dbManager=new DataAccess();
//		    
//		//dbManager.close();
//
//		
//	}
	
    public BLFacadeImplementation(DataAccess da)  {
		
		System.out.println("Creating BLFacadeImplementation instance with DataAccess parameter");
//		ConfigXML c=ConfigXML.getInstance();
		
		dbManager=da;		
	}
    
    
    /**
     * {@inheritDoc}
     */
    @WebMethod public List<String> getDepartCities(){
    	dbManager.open();	
		
		 List<String> departLocations=dbManager.getDepartCities();		

		dbManager.close();
		
		return departLocations;
    	
    }
    /**
     * {@inheritDoc}
     */
	@WebMethod public List<String> getDestinationCities(String from){
		dbManager.open();	
		
		 List<String> targetCities=dbManager.getArrivalCities(from);		

		dbManager.close();
		
		return targetCities;
	}

	/**
	 * {@inheritDoc}
	 */
   @WebMethod
   public Ride createRide( String from, String to, Date date, int nPlaces, float price, String driverEmail ) throws RideMustBeLaterThanTodayException, RideAlreadyExistException{
	   
		dbManager.open();
		Ride ride=dbManager.createRide(from, to, date, nPlaces, price, driverEmail);		
		dbManager.close();
		return ride;
   };
	
   /**
    * {@inheritDoc}
    */
	@WebMethod 
	public List<Ride> getRides(String from, String to, Date date){
		dbManager.open();
		List<Ride>  rides=dbManager.getRides(from, to, date);
		dbManager.close();
		return rides;
	}

    
	/**
	 * {@inheritDoc}
	 */
	@WebMethod 
	public List<Date> getThisMonthDatesWithRides(String from, String to, Date date){
		dbManager.open();
		List<Date>  dates=dbManager.getThisMonthDatesWithRides(from, to, date);
		dbManager.close();
		return dates;
	}
	
	public User createUser(String name, String email, String password, String mota) {
		dbManager.open();
		User  user=dbManager.createUser(email, name, password, mota);
		dbManager.close();
		return user;
	}
	
	public boolean LoginDriver(String email, String password) {
		dbManager.open();
		Boolean  dago=dbManager.LoginDriver(email, password);
		dbManager.close();
		return dago;
	}
	
	public boolean LoginTraveler(String email, String password) {
		dbManager.open();
		Boolean  dago=dbManager.LoginTraveler(email, password);
		dbManager.close();
		return dago;
	}
	
	public Reserba addReserba(Reserba reserba) {
		dbManager.open();
		Reserba  berria=dbManager.addReserba(reserba);
		dbManager.close();
		return berria;
	}
	
	public List<Reserba> reserbakLortu(String traveler){
		dbManager.open();
		List<Reserba>  reserbak=dbManager.reserbakLortu(traveler);
		dbManager.close();
		return reserbak;
	}
	
	
	public void close() {

		dbManager.close();

	}

	/**
	 * {@inheritDoc}
	 */
    @WebMethod	
	 public void initializeBD(){
    	dbManager.open();
		dbManager.initializeDB();
		dbManager.close();
	}

}

