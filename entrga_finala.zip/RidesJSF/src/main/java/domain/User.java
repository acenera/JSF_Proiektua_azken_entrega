package domain;

public class User {

}
