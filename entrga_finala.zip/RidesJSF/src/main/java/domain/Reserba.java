package domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

@SuppressWarnings("serial")
@XmlAccessorType(XmlAccessType.FIELD)
@Entity
public class Reserba {

	@Id 
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer reserbaNumber;
	private String traveler;
	@ManyToOne
	private Ride ride;
	
	public Reserba() {
		
	}
	
	public Reserba(String traveler, Ride ride) {
		this.traveler=traveler;
		this.ride=ride;
	}

	public Integer getReserbaNumber() {
		return reserbaNumber;
	}

	public void setReserbaNumber(Integer reserbaNumber) {
		this.reserbaNumber = reserbaNumber;
	}

	public String getTraveler() {
		return traveler;
	}

	public void setTraveler(String traveler) {
		this.traveler = traveler;
	}

	public Ride getRide() {
		return ride;
	}

	public void setRide(Ride ride) {
		this.ride = ride;
	}
	
	
}
